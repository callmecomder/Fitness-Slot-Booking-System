from queue import Full
from django.db import models
from django.utils import timezone

class Class(models.Model):
    YOGA = 'Yoga'
    GYM = 'Gym'
    DANCE = 'Dance'
    CLASS_TYPE_CHOICES = [
        (YOGA, 'Yoga'),
        (GYM, 'Gym'),
        (DANCE, 'Dance'),
    ]

    class_type = models.CharField(max_length=10, choices=CLASS_TYPE_CHOICES)
    date = models.DateTimeField()
    capacity = models.PositiveIntegerField()
    booked_slots = models.PositiveIntegerField(default=0)
    waiting_list = models.JSONField(default=list)  # Stores user IDs in waiting list

class Booking(models.Model):

    name = models.CharField(max_length=100, default=Full)
    user_id = models.CharField(max_length=100)  # Can be replaced with a more secure user reference
    class_instance = models.ForeignKey(Class, on_delete=models.CASCADE)
    booked_at = models.DateTimeField(default=timezone.now)
