import logo from './logo.svg';
import './App.css';
import React, { useRef } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import BookingForm from './components/BookingForm';
import CancelBooking from './components/CancelBooking';
import BookingDetailsPage from './components/BookingDetails';



function App() {
  return (
    <div>
      {/* Display the logo */}
      <img src={"tawgl-logo.png"} alt="logo" style={{height : "80px", width : "180px"}} />      
      <h1><strong>Fitness Slot Booking System</strong></h1>
      <BookingForm />
      <br/>
      <CancelBooking />
      <br/>
      <BookingDetailsPage />
    </div>
  );
}


export default App;
