import React, { useState } from 'react';
import './CancelBooking.css'; // Import the CSS file

function CancelBooking() {
  const [bookingId, setBookingId] = useState('');
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleCancel = () => {
    fetch('/api/cancel', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ booking_id: bookingId }),
    })
      .then(response => response.json())
      .then(data => {
        if (data.message) {
          setMessage('Booking cancelled successfully!');
          setIsSuccess(true); // Success statex
        } else if (data.error) {
          setMessage(data.error);
          setIsSuccess(false); // Error state
        }
      })
      .catch(error => {
        console.error('Error:', error);
        setMessage('An unexpected error occurred.');
        setIsSuccess(false); // Error state
      });
  };

  return (
    <div className="container">
      <h2>Cancel Booking</h2>
      <input
        type="text"
        placeholder="Booking ID"
        value={bookingId}
        onChange={(e) => setBookingId(e.target.value)}
      />
      <button onClick={handleCancel}>Cancel Booking</button>
      
      {/* Conditionally render message with appropriate styling */}
      {message && (
        <p className={isSuccess ? 'success-message' : 'error-message'}>
          {message}
        </p>
      )}
    </div>
  );
}

export default CancelBooking;
