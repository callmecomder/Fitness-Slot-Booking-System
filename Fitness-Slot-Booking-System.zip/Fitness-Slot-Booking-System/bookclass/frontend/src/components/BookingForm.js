import React, { useState } from 'react';
import './ClassBookingForm.css'; // Import your CSS file

const ClassBookingForm = () => {
  const [name, setName] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const classes = [
    { id: 1, name: 'Gym' },
    { id: 2, name: 'Yoga' },
    { id: 3, name: 'Dance' }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Send data to the backend
    const response = await fetch('/api/book', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        class_id: selectedClass,
      }),
    });

    const data = await response.json();

    if (response.ok) {
      setMessage('Booking successful!');
      setIsSuccess(true); // Set to true for success
    } else {
      setMessage(`Error: ${data.error}`);
      setIsSuccess(false); // Set to false for error
    }
  };

  return (
    <div className="container">
      <h1>Book a Class</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Enter your name: </label>
          <input 
            type="text" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            required 
          />
        </div>
        <div>
          <label>Select a class: </label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            required
          >
            <option value="" disabled>Select a class</option>
            {classes.map((classOption) => (
              <option key={classOption.id} value={classOption.id}>
                {classOption.name}
              </option>
            ))}
          </select>
        </div>
        <button type="submit">Book Class</button>
      </form>
      {message && (
        <p className={isSuccess ? 'success-message' : 'error-message'}>
          {message}
        </p>
      )}
    </div>
  );
};

export default ClassBookingForm;
