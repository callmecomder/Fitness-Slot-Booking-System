import React, { useState } from 'react';
import axios from 'axios';
import './BookingDetails.css'; // Import the CSS file for styling

const BookingDetails = () => {
  const [classId, setClassId] = useState('');
  const [date, setDate] = useState('');
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  // Mapping class types to class IDs
  const classOptions = [
    { id: '1', name: 'Gym' },
    { id: '2', name: 'Yoga' },
    { id: '3', name: 'Dance' },
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Construct the API URL with optional parameters
    let url = `/api/booking-details/`;
    if (classId || date) {
      url += `?`;
      if (classId) {
        url += `class_id=${classId}&`;
      }
      if (date) {
        url += `date=${date}`;
      }
    }

    try {
      // Send GET request to fetch booking details
      const response = await axios.get(url);
      setBookings(response.data); // Set the bookings to state
      setError(''); // Clear any previous errors
    } catch (err) {
      // Handle error (e.g., no bookings found)
      setError(err.response?.data?.message || 'An error occurred');
      setBookings([]);
    }
  };

  const handleClear = () => {
    setClassId('');
    setDate('');
    setBookings([]);
    setError('');
  };

  return (
    <div className="booking-container">
      <h1>Booking Details</h1>

      <form onSubmit={handleSubmit} className="booking-form">
        <div className="form-group">
          <label>Class Type:</label>
          <select value={classId} onChange={(e) => setClassId(e.target.value)} className="form-control">
            <option value="">Select Class Type</option>
            {classOptions.map((classOption) => (
              <option key={classOption.id} value={classOption.id}>
                {classOption.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Date:</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="form-control"
          />
        </div>

        <div className="button-group">
          <button type="submit" className="btn">Search</button>
          <button type="button" onClick={handleClear} className="btn clear-btn">Clear</button>
        </div>
      </form>

      <div>
        {bookings.length > 0 ? (
          <div className="booking-list">
            <h2>Bookings:</h2>
            {bookings.map((booking) => (
              <div key={booking.id} className="booking-card">
                <p><strong>Booking ID:</strong> {booking.id}</p>
                <p><strong>Name:</strong> {booking.name}</p>
                <p><strong>User ID:</strong> {booking.user_id}</p>
                <p><strong>Booked At:</strong> {new Date(booking.booked_at).toLocaleString()}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="error-message">{error}</p>
        )}
      </div>
    </div>
  );
};

export default BookingDetails;
